var searchData=
[
  ['_7eworker_0',['~Worker',['../class_worker.html#aa8e4543ef1e93fd9d884269ba30c5bfe',1,'Worker']]]
];
