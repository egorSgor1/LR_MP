var searchData=
[
  ['junior_0',['junior',['../lw1_8cpp.html#ab91b34ae619fcdfcba4522b4f335bf83ab03e3fd2b3d22ff6df2796c412b09311',1,'lw1.cpp']]]
];
