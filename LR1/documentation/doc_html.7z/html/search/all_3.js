var searchData=
[
  ['get_5finfo_0',['get_info',['../class_worker.html#a004043aa13b5931d0f7f7830e4991a2b',1,'Worker']]]
];
