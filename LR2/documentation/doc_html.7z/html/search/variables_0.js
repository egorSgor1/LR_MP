var searchData=
[
  ['color_0',['color',['../class_r_b_node.html#a0877ab978b0055833f3a5266491f1f2e',1,'RBNode']]]
];
