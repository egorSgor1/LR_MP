var searchData=
[
  ['color_0',['Color',['../_r_b_node_8h.html#ab87bacfdad76e61b9412d7124be44c1c',1,'RBNode.h']]]
];
