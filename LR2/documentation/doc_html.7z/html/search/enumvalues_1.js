var searchData=
[
  ['chief_0',['chief',['../_worker_8h.html#ab91b34ae619fcdfcba4522b4f335bf83a80dbf87f21babc680482e0b37bff584d',1,'Worker.h']]]
];
