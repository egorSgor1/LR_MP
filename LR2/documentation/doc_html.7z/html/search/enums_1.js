var searchData=
[
  ['department_0',['Department',['../_worker_8h.html#a938069f766288326dabb8a8f0cd83bce',1,'Worker.h']]]
];
