var searchData=
[
  ['manager_0',['manager',['../_worker_8h.html#ab91b34ae619fcdfcba4522b4f335bf83a1d0258c2440a8d19e716292b231e3190',1,'Worker.h']]],
  ['middle_1',['middle',['../_worker_8h.html#ab91b34ae619fcdfcba4522b4f335bf83a4a548addbfb239bbd12f5afe11a4b6dc',1,'Worker.h']]]
];
