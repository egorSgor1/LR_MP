var searchData=
[
  ['get_5ffullname_0',['get_fullname',['../class_worker.html#ae63ed9d9fdc3d30824aef397b723f858',1,'Worker']]],
  ['get_5finfo_1',['get_info',['../class_worker.html#a3fbd0e077267dbd19e2deccd485c90ce',1,'Worker']]]
];
