var searchData=
[
  ['parent_0',['parent',['../class_r_b_node.html#a131e0d1a4f73d55e6b5ad282c6846612',1,'RBNode']]],
  ['position_1',['Position',['../_worker_8h.html#ab91b34ae619fcdfcba4522b4f335bf83',1,'Worker.h']]]
];
