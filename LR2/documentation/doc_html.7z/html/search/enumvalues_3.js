var searchData=
[
  ['junior_0',['junior',['../_worker_8h.html#ab91b34ae619fcdfcba4522b4f335bf83ab03e3fd2b3d22ff6df2796c412b09311',1,'Worker.h']]]
];
