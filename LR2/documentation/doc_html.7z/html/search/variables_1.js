var searchData=
[
  ['data_0',['data',['../class_bi_node.html#aa4309cef21c081e86bcc8929878f76c2',1,'BiNode::data'],['../class_h_node.html#a95e1465e682434a3c4f00e4c6089e9f0',1,'HNode::data'],['../class_r_b_node.html#aadf2a28ffe3954410ec1e726fd40c309',1,'RBNode::data']]]
];
